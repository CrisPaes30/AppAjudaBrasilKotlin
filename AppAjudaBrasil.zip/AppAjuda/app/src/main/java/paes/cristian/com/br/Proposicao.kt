package paes.cristian.com.br

data class Proposicao (var id: Int,
var uri: String,
var siglaTipo: String,
var ano: Int,
var ementa: String)