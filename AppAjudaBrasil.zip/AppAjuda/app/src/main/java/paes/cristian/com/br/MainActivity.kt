package paes.cristian.com.br

import android.os.Bundle
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    var list: MutableList<Proposicao> = emptyList<Proposicao>().toMutableList()
    lateinit var recyclerView: RecyclerView
    lateinit var adapter: ProposicoesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        list.add(Proposicao(1,"","PEC", 2019, "Emneta de teste do projeto"))

        recyclerView = findViewById(R.id.rv_propositicoes)
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        adapter -= ProposicoesAdapter(list, this)
        recyclerView.adapter = adapter
    }

}